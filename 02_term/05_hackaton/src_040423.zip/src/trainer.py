"""
Данный файл является примером загрузки параметров, вывода и записи метрик
"""

import json

import dvc.api

# читаем параметры
params = dvc.api.params_show()
# params - словарь с параметрами, прочитанных из params.yaml

lr = params["tuning"]["learning_rate"]

# выполняем целевые действия
# xxx
# xxx
# xxx
# xxx
# xxx


# сохраняем метрики

# для сохранения метрик нам нужно подготовить словарь
metrics = {
    "avg_precision": {"train": 0.9872271756725741, "test": 0.9549556493816984}
}


with open("metrics/model.json", "w") as metrics_file:
    json.dump(metrics, metrics_file)


# сохраняем выходной файл
with open("data/test.txt", "w") as output_file:
    output_file.write("hello")
